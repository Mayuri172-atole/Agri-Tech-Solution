import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MdDashboard, MdInventory, MdShoppingCart, MdHistory, MdLogout, MdVerifiedUser, MdListAlt, MdPayment, MdArrowForward } from 'react-icons/md';

// COMPONENTS IMPORT
import SupplierLedger from './SupplierLedger'; 
import Inventory from './Inventory'; 
import '../../styles/SupplierDashboard/SupplierHome.css';

const SupplierHome = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('home'); 
  const [userData, setUserData] = useState({
    name: "Supplier",
    category: "Farmer",
    isVerified: false
  });

  useEffect(() => {
    const email = localStorage.getItem('activeUserEmail');
    const category = localStorage.getItem('userCategory') || 'Farmer';
    const name = localStorage.getItem('userName') || 'Agri Supplier';
    const verificationStatus = localStorage.getItem(`isVerified_${email}`) === 'true';

    setUserData({ name, category, isVerified: verificationStatus });
  }, []);

  const handleLogout = () => {
    localStorage.clear();
    navigate('/');
  };

  const isDealer = userData.category === 'Pesticide/Fertilizer';

  return (
    <div className="supplier-container">
      {/* --- SIDEBAR --- */}
      <aside className="supplier-sidebar">
        <div className="sidebar-logo">AgriMart {isDealer ? 'Dealer' : 'Farmer'}</div>
        <nav>
          <div className={`sidebar-link ${activeTab === 'home' ? 'active' : ''}`} onClick={() => setActiveTab('home')}>
            <MdDashboard /> Dashboard
          </div>
          <div className={`sidebar-link ${activeTab === 'inventory' ? 'active' : ''}`} onClick={() => setActiveTab('inventory')}>
            <MdInventory /> {isDealer ? 'Add Chemical' : 'Add Crop'}
          </div>
          <div className={`sidebar-link ${activeTab === 'ledger' ? 'active' : ''}`} onClick={() => setActiveTab('ledger')}>
            <MdListAlt /> My Stock & Sales
          </div>
          <div className={`sidebar-link ${activeTab === 'orders' ? 'active' : ''}`} onClick={() => setActiveTab('orders')}>
            <MdShoppingCart /> Orders
          </div>
          <div className={`sidebar-link ${activeTab === 'payments' ? 'active' : ''}`} onClick={() => setActiveTab('payments')}>
            <MdPayment /> Payments
          </div>
        </nav>
        
        <button onClick={handleLogout} className="sidebar-link logout-btn" style={{marginTop: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: 'white'}}>
          <MdLogout /> Logout
        </button>
      </aside>

      {/* --- MAIN CONTENT --- */}
      <main className="supplier-main">
        <header className="dashboard-header">
          <div>
            <h2>Ram Ram, {userData.name} {isDealer ? '🧪' : '🚜'}</h2>
            <p>{isDealer ? 'Fertilizer & Pesticide Control' : 'Farm Fresh Produce Management'}</p>
          </div>
          <span className={`status-badge ${userData.isVerified ? 'status-live' : 'status-pending'}`}>
            {userData.isVerified ? <><MdVerifiedUser /> Verified</> : '● Pending Approval'}
          </span>
        </header>

        <section className="dynamic-content">
          
          {/* 1. DASHBOARD VIEW (SAAF & CLEAN) */}
          {activeTab === 'home' && (
            <>
              <div className="stats-grid">
                <div className="stat-card"><p>Total Revenue</p><h3>₹54,200</h3></div>
                <div className="stat-card"><p>Active Stock Items</p><h3>24</h3></div>
                <div className="stat-card urgent"><p>Pending Orders</p><h3>08</h3></div>
              </div>

              {/* QUICK REDIRECT BUTTONS SECTION */}
              <h3 style={{marginTop: '40px', marginBottom: '20px'}}>Quick Actions ⚡</h3>
              <div className="redirect-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                
                {/* Button to Add Products */}
                <div className="action-card-redirect" onClick={() => setActiveTab('inventory')} 
                     style={{ background: '#fff', padding: '25px', borderRadius: '15px', cursor: 'pointer', boxShadow: '0 4px 10px rgba(0,0,0,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderLeft: '6px solid #2ecc71' }}>
                  <div>
                    <h4 style={{margin: 0}}>{isDealer ? 'Add New Fertilizer' : 'List New Crop'}</h4>
                    <p style={{margin: '5px 0 0', fontSize: '14px', color: '#666'}}>Stock update karne ke liye yahan click karein</p>
                  </div>
                  <MdArrowForward size={24} color="#2ecc71" />
                </div>

                {/* Button to My Stock & Sales */}
                <div className="action-card-redirect" onClick={() => setActiveTab('ledger')} 
                     style={{ background: '#fff', padding: '25px', borderRadius: '15px', cursor: 'pointer', boxShadow: '0 4px 10px rgba(0,0,0,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderLeft: '6px solid #3498db' }}>
                  <div>
                    <h4 style={{margin: 0}}>View Stock & Sales Report</h4>
                    <p style={{margin: '5px 0 0', fontSize: '14px', color: '#666'}}>Database aur sales history dekhne ke liye</p>
                  </div>
                  <MdArrowForward size={24} color="#3498db" />
                </div>

              </div>

              {/* Ek chota sa Recent activity preview (Optional) */}
              <div style={{marginTop: '40px'}}>
                 <h3>Recent Order Preview</h3>
                 <div style={{background: '#fff', padding: '15px', borderRadius: '10px', fontSize: '14px', color: '#555'}}>
                   Order #AG-8821 (Ram Singh) - <strong>Shipped</strong>
                 </div>
              </div>
            </>
          )}

          {/* 2. INVENTORY FORM VIEW */}
          {activeTab === 'inventory' && (
            <div className="form-container">
               <Inventory />
            </div>
          )}

          {/* 3. FULL LEDGER VIEW */}
          {activeTab === 'ledger' && <SupplierLedger />}

          {/* 4. PAYMENTS VIEW */}
          {activeTab === 'payments' && (
            <div className="payments-placeholder" style={{padding: '20px', background: '#fff', borderRadius: '15px'}}>
              <h3>💰 Payment History</h3>
              <p>No recent payments found.</p>
            </div>
          )}

          {/* 5. ORDERS VIEW */}
          {activeTab === 'orders' && (
            <div style={{padding: '20px', background: '#fff', borderRadius: '15px'}}>
              <h3>📦 Manage Orders</h3>
              <p>Check and ship your pending orders here.</p>
            </div>
          )}

        </section>
      </main>
    </div>
  );
};

export default SupplierHome;