import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import axios from 'axios'; // 👈 Axios import kar lena
import '../../styles/SupplierDashboard/SupplierHome.css'; 

const Inventory = () => {
  const email = localStorage.getItem('activeUserEmail');
  const userCategory = localStorage.getItem('userCategory'); 
  
  const isDealer = userCategory === 'Pesticide/Fertilizer';
  const isVerified = localStorage.getItem(`isVerified_${email}`) === 'true';

  const [myProducts, setMyProducts] = useState([]);

  const [product, setProduct] = useState({
    name: '',
    price: '',
    stock: '',
    category: isDealer ? 'Pesticide' : 'Vegetables',
    description: '',
    chemicalInfo: '', 
    expiryDate: '',
    image: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2' // Default image for DB
  });

  // --- 1. DB aur LocalStorage se data load karo ---
  const loadData = async () => {
    try {
      // Pehle backend se fresh data lao
      const { data } = await axios.get('http://localhost:5000/api/products');
      const myData = data.filter(p => p.seller === email);
      
      if (myData.length > 0) {
        setMyProducts(myData);
      } else {
        // Agar DB khali hai toh LocalStorage check karo
        const key = isDealer ? 'pendingChemicals' : 'farmerStock';
        const savedData = JSON.parse(localStorage.getItem(key) || '[]');
        setMyProducts(savedData.filter(p => p.seller === email));
      }
    } catch (err) {
      console.log("DB connection issues, showing local data.");
    }
  };

  useEffect(() => {
    loadData();
  }, [isDealer, email]);

  // --- 2. Submit Logic (Local + Database) ---
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (isDealer && !isVerified) {
      return toast.error("Bidu rukh! Admin approval ke bina Pesticides add nahi kar sakte.");
    }

    const productType = isDealer ? 'licensed' : 'fresh';
    const status = isDealer ? 'Pending Approval' : 'Live';

    const newProduct = { 
      ...product, 
      id: Date.now(), 
      productType, 
      status, 
      seller: email,
      sellerName: localStorage.getItem('userName') || 'Agri Seller',
      dateAdded: new Date().toLocaleDateString(),
      countInStock: parseInt(product.stock) || 10 // Backend compatibility
    };

    try {
      //  Step A: MongoDB mein bhejo
      await axios.post('http://localhost:5000/api/products', newProduct);

      //  Step B: LocalStorage backup (Tera purana logic)
      const key = isDealer ? 'pendingChemicals' : 'farmerStock';
      const existingData = JSON.parse(localStorage.getItem(key) || '[]');
      localStorage.setItem(key, JSON.stringify([...existingData, newProduct]));

      const allProducts = JSON.parse(localStorage.getItem('all_products') || '[]');
      localStorage.setItem('all_products', JSON.stringify([...allProducts, newProduct]));

      // UI Update
      setMyProducts([...myProducts, newProduct]);
      
      toast.success(isDealer 
        ? "Chemical sent for verification! " 
        : "Produce is now Live on Marketplace! "
      );

      // Form Reset
      setProduct({ 
        name: '', price: '', stock: '', 
        category: isDealer ? 'Pesticide' : 'Vegetables', 
        description: '', chemicalInfo: '', expiryDate: '',
        image: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2'
      });

    } catch (error) {
      console.error(error);
      toast.error("Database Connection Fail! Check your backend, Bidu.");
    }
  };

  return (
    <div className="supplier-container">
      <main className="supplier-main">
        <div className="form-card" style={{ maxWidth: '800px', margin: '0 auto', background: '#fff', padding: '30px', borderRadius: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
          
          <div className="dashboard-header" style={{ marginBottom: '25px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <h2 style={{ color: '#2d3436' }}>{isDealer ? "Add Chemical/Fertilizer Stock" : "List Your Harvest"}</h2>
              <p style={{ fontSize: '14px', color: '#636e72' }}>Add items for the AgriMart marketplace</p>
            </div>
            <span className={`status-badge ${isVerified ? 'status-live' : 'status-pending'}`} style={{ padding: '8px 15px', borderRadius: '20px', fontSize: '12px', fontWeight: 'bold', background: isVerified ? '#e8f5e9' : '#fff3e0', color: isVerified ? '#2e7d32' : '#d35400' }}>
              {isDealer ? (isVerified ? '● Verified Dealer' : '● Under Review') : '● Active Farmer'}
            </span>
          </div>

          <form onSubmit={handleSubmit} className="inventory-form">
            {/* Input Row 1 */}
            <div className="input-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '15px' }}>
              <div className="input-group">
                <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600' }}>Product Name</label>
                <input 
                  type="text" 
                  className="sup-input"
                  placeholder={isDealer ? "e.g. Glyphosate 41% SL" : "e.g. Fresh Organic Potatoes"} 
                  value={product.name}
                  onChange={(e) => setProduct({...product, name: e.target.value})}
                  required 
                  style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1.5px solid #dcdde1' }}
                />
              </div>
              <div className="input-group">
                <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600' }}>Category</label>
                <select 
                  className="sup-select"
                  value={product.category}
                  onChange={(e) => setProduct({...product, category: e.target.value})}
                  style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1.5px solid #dcdde1' }}
                >
                  {isDealer ? (
                    <>
                      <option value="Pesticide">Pesticide</option>
                      <option value="Fertilizer">Fertilizer</option>
                      <option value="Seeds">Hybrid Seeds</option>
                    </>
                  ) : (
                    <>
                      <option value="Vegetables">Vegetables</option>
                      <option value="Fruits">Fruits</option>
                      <option value="Grains">Grains/Pulses</option>
                    </>
                  )}
                </select>
              </div>
            </div>

            {/* Input Row 2 */}
            <div className="input-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '15px' }}>
              <div className="input-group">
                <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600' }}>Price (₹)</label>
                <input 
                  type="number" 
                  className="sup-input"
                  placeholder="0.00" 
                  value={product.price}
                  onChange={(e) => setProduct({...product, price: e.target.value})}
                  required 
                  style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1.5px solid #dcdde1' }}
                />
              </div>
              <div className="input-group">
                <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600' }}>Stock Quantity</label>
                <input 
                  type="text" 
                  className="sup-input"
                  placeholder="e.g. 100" 
                  value={product.stock}
                  onChange={(e) => setProduct({...product, stock: e.target.value})}
                  required 
                  style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1.5px solid #dcdde1' }}
                />
              </div>
            </div>

            {isDealer && (
              <div className="dealer-specific-fields" style={{ background: '#f8f9fa', padding: '20px', borderRadius: '10px', marginBottom: '15px', borderLeft: '4px solid #2e7d32' }}>
                <div className="input-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                  <div className="input-group">
                    <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600' }}>Chemical Batch No.</label>
                    <input 
                      type="text" 
                      placeholder="e.g. MH-BATCH-2024" 
                      value={product.chemicalInfo}
                      onChange={(e) => setProduct({...product, chemicalInfo: e.target.value})}
                      required 
                      style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1.5px solid #dcdde1' }}
                    />
                  </div>
                  <div className="input-group">
                    <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600' }}>Expiry Date</label>
                    <input 
                      type="date" 
                      value={product.expiryDate}
                      onChange={(e) => setProduct({...product, expiryDate: e.target.value})}
                      required 
                      style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1.5px solid #dcdde1' }}
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="input-group" style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600' }}>Product Description</label>
              <textarea 
                rows="3" 
                placeholder="Mention usage instructions..."
                value={product.description}
                onChange={(e) => setProduct({...product, description: e.target.value})}
                style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1.5px solid #dcdde1' }}
              ></textarea>
            </div>

            <button 
              type="submit" 
              className={`btn-list ${isDealer && !isVerified ? 'disabled-btn' : ''}`}
              style={{
                width: '100%',
                padding: '15px',
                background: (isDealer && !isVerified) ? '#ccc' : '#2e7d32',
                color: '#fff',
                border: 'none',
                borderRadius: '10px',
                fontWeight: 'bold',
                cursor: (isDealer && !isVerified) ? 'not-allowed' : 'pointer',
                transition: '0.3s'
              }}
              disabled={isDealer && !isVerified}
            >
              {isDealer 
                ? (isVerified ? " SUBMIT TO MARKETPLACE" : "🔒 WAITING FOR ADMIN") 
                : " POST HARVEST NOW"}
            </button>
          </form>

          {/* Table Section */}
          <div className="my-stock-table" style={{ marginTop: '40px' }}>
            <h3 style={{ borderTop: '1px solid #eee', paddingTop: '20px', color: '#2d3436' }}>My Listings</h3>
            <table style={{ width: '100%', marginTop: '15px', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '2px solid #eee' }}>
                  <th style={{ padding: '10px' }}>Product</th>
                  <th>Stock</th>
                  <th>Price</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {myProducts.length > 0 ? myProducts.map(p => (
                  <tr key={p._id || p.id} style={{ borderBottom: '1px solid #f9f9f9' }}>
                    <td style={{ padding: '10px' }}>{p.name}</td>
                    <td>{p.stock}</td>
                    <td>₹{p.price}</td>
                    <td>
                      <span style={{ 
                        fontSize: '11px', padding: '3px 8px', borderRadius: '10px',
                        background: p.status === 'Live' ? '#e8f5e9' : '#fff3e0',
                        color: p.status === 'Live' ? '#2e7d32' : '#d35400'
                      }}>
                        {p.status}
                      </span>
                    </td>
                  </tr>
                )) : (
                  <tr><td colSpan="4" style={{ textAlign: 'center', padding: '20px', color: '#999' }}>No items added yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Inventory; 