import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import { HiOutlineBadgeCheck, HiTruck, HiHome, HiShoppingBag, HiChevronDown, HiChevronUp } from 'react-icons/hi';

const TrackOrder = () => {
  const [orderItems, setOrderItems] = useState([]);
  // Track karne ke liye ki konsa item open hai
  const [expandedIndex, setExpandedIndex] = useState(null);

  useEffect(() => {
    const savedOrder = localStorage.getItem('lastOrder');
    if (savedOrder) {
      setOrderItems(JSON.parse(savedOrder));
    }
  }, []);

  const getStages = (statusIndex) => [
    { label: 'Placed', icon: <HiShoppingBag />, status: statusIndex >= 0 ? 'completed' : 'pending' },
    { label: 'Shipped', icon: <HiOutlineBadgeCheck />, status: statusIndex >= 1 ? 'completed' : statusIndex === 0 ? 'current' : 'pending' },
    { label: 'Out for Delivery', icon: <HiTruck />, status: statusIndex >= 2 ? 'completed' : statusIndex === 1 ? 'current' : 'pending' },
    { label: 'Delivered', icon: <HiHome />, status: statusIndex >= 3 ? 'completed' : statusIndex === 2 ? 'current' : 'pending' }
  ];

  const handleToggle = (idx) => {
    setExpandedIndex(expandedIndex === idx ? null : idx);
  };

  return (
    <div style={{ background: '#f0f2f5', minHeight: '100vh', paddingBottom: '50px' }}>
      <Navbar />
      <div style={{ maxWidth: '800px', margin: '30px auto', padding: '0 20px' }}>
        <h2 style={{ marginBottom: '10px', color: '#1a1a1a', fontWeight: '800' }}>Order Tracking</h2>
        <p style={{ marginBottom: '25px', color: '#666' }}>Click on a product to explore tracking details.</p>

        {orderItems.length > 0 ? (
          orderItems.map((item, idx) => {
            const currentStatusIndex = (idx % 3);
            const stages = getStages(currentStatusIndex);
            const isExpanded = expandedIndex === idx;

            return (
              <div key={idx} style={orderCardStyle}>
                {/* Product Header - Ab ye Clickable hai */}
                <div 
                  style={{ ...productHeaderStyle, cursor: 'pointer' }} 
                  onClick={() => handleToggle(idx)}
                >
                  <img src={item.image} alt={item.name} style={imgStyle} />
                  <div style={{ flex: 1 }}>
                    <h3 style={{ margin: 0, fontSize: '18px' }}>{item.name}</h3>
                    <p style={{ margin: '4px 0', color: '#666', fontSize: '14px' }}>Qty: {item.quantity || 1} | ₹{item.price}</p>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                    <div style={badgeStyle(currentStatusIndex)}>
                      {currentStatusIndex === 2 ? 'Out for Delivery' : currentStatusIndex === 1 ? 'Shipped' : 'Processing'}
                    </div>
                    {isExpanded ? <HiChevronUp size={24} color="#999" /> : <HiChevronDown size={24} color="#999" />}
                  </div>
                </div>

                {/* Individual Tracking Path - Sirf expand hone par dikhega */}
                {isExpanded && (
                  <div style={{ marginTop: '20px', animation: 'fadeIn 0.4s ease' }}>
                    <hr style={{ border: '0', borderTop: '1px solid #eee', margin: '20px 0' }} />
                    <div style={pathContainerStyle}>
                      {stages.map((stage, sIdx) => (
                        <div key={sIdx} style={{ flex: 1, position: 'relative', textAlign: 'center' }}>
                          {/* Connecting Line */}
                          {sIdx !== stages.length - 1 && (
                            <div style={{
                              position: 'absolute', top: '20px', left: '50%', width: '100%', height: '3px',
                              background: stage.status === 'completed' ? '#2e7d32' : '#e0e0e0',
                              zIndex: 1
                            }}></div>
                          )}
                          
                          {/* Circle Icon */}
                          <div style={{
                            width: '40px', height: '40px', borderRadius: '50%', margin: '0 auto', position: 'relative', zIndex: 2,
                            display: 'flex', justifyContent: 'center', alignItems: 'center',
                            background: stage.status === 'completed' ? '#2e7d32' : stage.status === 'current' ? '#fb641b' : '#fff',
                            color: (stage.status === 'completed' || stage.status === 'current') ? '#fff' : '#bdbdbd',
                            border: '2px solid',
                            borderColor: stage.status === 'completed' ? '#2e7d32' : stage.status === 'current' ? '#fb641b' : '#e0e0e0',
                            boxShadow: stage.status === 'current' ? '0 0 10px rgba(251, 100, 27, 0.4)' : 'none'
                          }}>
                            {React.cloneElement(stage.icon, { size: 20 })}
                          </div>

                          <p style={{ 
                            fontSize: '12px', marginTop: '8px', fontWeight: '600',
                            color: stage.status === 'pending' ? '#bdbdbd' : '#333' 
                          }}>
                            {stage.label}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div style={{ textAlign: 'center', padding: '50px', background: '#fff', borderRadius: '15px' }}>
            <p>Bidu, koi order record nahi mila! Kheti shuru kar.</p>
          </div>
        )}
      </div>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

// --- STYLES (Same as yours, no disturbance) ---
const orderCardStyle = {
  background: '#fff', padding: '25px', borderRadius: '18px',
  boxShadow: '0 10px 25px rgba(0,0,0,0.05)', marginBottom: '25px',
  border: '1px solid #f1f1f1'
};

const productHeaderStyle = { display: 'flex', gap: '20px', alignItems: 'center', flexWrap: 'wrap' };
const imgStyle = { width: '75px', height: '75px', borderRadius: '12px', objectFit: 'cover', background: '#f9f9f9', border: '1px solid #eee' };

const badgeStyle = (index) => ({
  padding: '6px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 'bold',
  background: index === 2 ? '#fff7ed' : index === 1 ? '#f0fdf4' : '#f8fafc',
  color: index === 2 ? '#c2410c' : index === 1 ? '#15803d' : '#64748b',
  border: `1px solid ${index === 2 ? '#ffedd5' : index === 1 ? '#dcfce7' : '#e2e8f0'}`
});

const pathContainerStyle = { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: '10px' };

export default TrackOrder;