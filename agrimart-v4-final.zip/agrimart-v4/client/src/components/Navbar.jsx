import React, { useState } from 'react';
import { HiOutlineSearch, HiOutlineUser, HiOutlineHeart, HiOutlineShoppingBag } from 'react-icons/hi';
import { MdLocalShipping, MdLogout, MdDashboard } from 'react-icons/md';
import { navData } from '../data/navData';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import '../styles/Navbar.css';

const Navbar = () => {
  const navigate = useNavigate();
  const { cartCount, wishlist } = useCart();
  const [searchTerm, setSearchTerm] = useState('');

  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  const userRole = localStorage.getItem('role');

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
    window.location.reload();
  };

  const handleSearch = (e) => {
    if (e.key === 'Enter' || e.type === 'click') {
      if (searchTerm.trim()) {
        navigate(`/marketplace?search=${searchTerm.toLowerCase().trim()}`);
        setSearchTerm('');
      }
    }
  };

  const mainLinks = [
    'HOME', 'BRANDS', 'SEEDS', 'CROP PROTECTION', 'CROP NUTRITION',
    'EQUIPMENTS', 'ORGANIC', 'TAPAS',
  ];

  return (
    <header className="navbar-container">
      {/* ── COMPANY HEADER BAND ──────────────────────────────────── */}
      <div className="company-header-band">
        <div className="company-band-inner">
          <div className="company-logo-block">
            {/* SVG Logo inspired by SEMENA letterhead globe/leaf design */}
            <svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="26" cy="26" r="24" fill="#1b5e20" stroke="#4caf50" strokeWidth="2"/>
              <ellipse cx="26" cy="26" rx="10" ry="22" stroke="#a5d6a7" strokeWidth="1.5" fill="none"/>
              <ellipse cx="26" cy="26" rx="22" ry="10" stroke="#a5d6a7" strokeWidth="1.5" fill="none"/>
              <line x1="4" y1="26" x2="48" y2="26" stroke="#a5d6a7" strokeWidth="1.2"/>
              <line x1="26" y1="4" x2="26" y2="48" stroke="#a5d6a7" strokeWidth="1.2"/>
              <path d="M16 34 Q20 24 26 18 Q32 24 36 34" stroke="#66bb6a" strokeWidth="2" fill="none"/>
              <circle cx="26" cy="18" r="3" fill="#81c784"/>
            </svg>
            <div className="company-text-block">
              <span className="company-name-main">SEMENA HYBRID SEEDS (INDIA) PVT. LTD.</span>
              <span className="company-tagline">Growing with Technology</span>
              <span className="project-subtitle">Agri-Tech-Solution</span>
            </div>
          </div>
          <div className="company-contact-block">
            <span>📞 +091 9518930913</span>
            <span>✉ semena_india@hotmail.com</span>
            <span>🌐 www.semenahybridseeds.com</span>
            <span className="cin-tag">CIN: U52609MH2018PTC303967</span>
          </div>
        </div>
      </div>

      {/* ── MAIN NAV ROW ─────────────────────────────────────────── */}
      <div className="main-nav">
        <div className="nav-content header-row">

          {/* SEARCH BAR */}
          <div className="search-section">
            <div className="search-bar-pro">
              <input
                type="text"
                placeholder="Search seeds, tools, brands, crops..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleSearch}
              />
              <button className="search-btn" onClick={handleSearch}>
                <HiOutlineSearch />
              </button>
            </div>
          </div>

          {/* UTILITY GROUP */}
          <div className="utility-group">
            <Link to="/track-order" className="utility-item">
              <MdLocalShipping />
              <span>Track Order</span>
            </Link>

            <Link to="/wishlist" className="utility-item cart-relative">
              <HiOutlineHeart />
              <span>Wishlist</span>
              {wishlist?.length > 0 && <span className="cart-badge">{wishlist.length}</span>}
            </Link>

            <Link to="/agribot" className="utility-item ai-link">
              <span>🤖</span>
              <span>AgriBot</span>
            </Link>

            <Link to="/crop-health" className="utility-item ai-link">
              <span>🔬</span>
              <span>CropAI</span>
            </Link>

            <Link to="/agritube" className="utility-item tube-link">
              <span>📹</span>
              <span>AgriTube</span>
            </Link>

            <div className="auth-field-stable">
              <div className="utility-item user-dropdown-parent dropdown-fix">
                <HiOutlineUser />
                {!isLoggedIn ? (
                  <>
                    <span>Login <small>▼</small></span>
                    <div className="auth-dropdown">
                      <Link to="/login">Customer Login</Link>
                      <Link to="/supplier-login">Seller / Farmer Zone</Link>
                      <Link to="/delivery-panel">🚚 Delivery Partner</Link>
                      <Link to="/signup" className="signup-highlight">New? Register Free</Link>
                    </div>
                  </>
                ) : (
                  <>
                    <span className="account-text-active">Account <small>▼</small></span>
                    <div className="auth-dropdown">
                      {userRole === 'customer' && <Link to="/customer-dashboard"><MdDashboard /> Dashboard</Link>}
                      {(userRole === 'supplier' || userRole === 'farmer' || userRole === 'dealer') && <Link to="/supplier-dashboard/home"><MdDashboard /> Seller Panel</Link>}
                      {userRole === 'admin' && <Link to="/admin-dashboard/home"><MdDashboard /> Admin Hub</Link>}
                      <Link to="/profile">👤 My Profile</Link>
                      <hr />
                      <button onClick={handleLogout} className="logout-btn-nav"><MdLogout /> Logout</button>
                    </div>
                  </>
                )}
              </div>
            </div>

            <div className="utility-item cart-btn">
              <Link to="/cart" className="util-box cart-relative">
                <HiOutlineShoppingBag />
                <span>Cart</span>
                {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* ── CATEGORY NAV ─────────────────────────────────────────── */}
      <nav className="category-nav">
        <div className="nav-content">
          <ul className="nav-menu">
            {mainLinks.map((link) => (
              <li key={link} className={`nav-item ${navData[link] ? 'has-dropdown' : ''}`}>
                {link === 'HOME' ? (
                  <Link to="/" className="nav-link-text">{link}</Link>
                ) : (
                  <span className="nav-link-text">{link}</span>
                )}
                {navData[link] && <span className="dropdown-arrow">▾</span>}
                {navData[link] && (
                  <div className="mega-menu">
                    <div className="mega-menu-inner">
                      {navData[link].map((column, idx) => (
                        <div className="menu-column" key={idx}>
                          <h4 className="column-title">{column.title}</h4>
                          <ul className="column-list">
                            {column.items.map((item) => (
                              <li key={item} className="column-item"><a href="#">{item}</a></li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </li>
            ))}

            {/* AI Feature Links */}
            <li className="nav-item">
              <Link to="/agribot" className="nav-link-text ai-nav-link">🤖 AgriBot</Link>
            </li>
            <li className="nav-item">
              <Link to="/crop-health" className="nav-link-text ai-nav-link">🔬 CropAI</Link>
            </li>
            <li className="nav-item">
              <Link to="/agritube" className="nav-link-text tube-nav-link">📹 AgriTube</Link>
            </li>
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;
