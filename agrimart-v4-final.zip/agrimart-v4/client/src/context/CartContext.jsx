import React, { createContext, useState, useContext } from 'react';
import toast from 'react-hot-toast';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [wishlist, setWishlist] = useState([]); // 1. Added Wishlist State

  // --- CART LOGIC ---
  const addToCart = (product) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.id === product.id);
      if (existingItem) {
        return prevCart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: (item.quantity || 1) + 1 }
            : item
        );
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });

    toast.success(`${product.name} added to cart!`, {
      id: product.id,
      duration: 3000,
      position: 'top-right',
      style: { border: '1px solid #2e7d32', padding: '16px', color: '#2e7d32', fontWeight: '600', borderRadius: '8px', background: '#fff' },
      iconTheme: { primary: '#2e7d32', secondary: '#fff' },
    });
  };

  const removeFromCart = (productId) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== productId));
    toast.error("Item removed from cart", {
        id: "cart-remove-action", 
        style: { borderRadius: '8px', background: '#333', color: '#fff' }
    });
  };

  const updateQuantity = (productId, newQty) => {
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.id === productId ? { ...item, quantity: newQty } : item
      )
    );
  };

  // --- WISHLIST LOGIC ---
  const moveToWishlist = (product) => {
    // Cart se hatao
    setCart((prevCart) => prevCart.filter((item) => item.id !== product.id));
    
    // Wishlist mein add karo (Check if already exists)
    setWishlist((prev) => {
      if (prev.find(item => item.id === product.id)) return prev;
      return [...prev, product];
    });

    toast(`${product.name} moved to wishlist!`, { 
      id: "wishlist-action", 
      icon: '❤️',
      style: { borderRadius: '8px', background: '#fff', color: '#333', border: '1px solid #ff4b2b' }
    });
  };

  const removeFromWishlist = (productId) => {
    setWishlist((prev) => prev.filter(item => item.id !== productId));
    toast.error("Removed from wishlist", { id: "wishlist-remove" });
  };

  // --- ORDER LOGIC ---
  const clearCart = () => {
    setOrders((prev) => [...prev, ...cart]); 
    setCart([]); 
  };

  const cartCount = cart.reduce((total, item) => total + (item.quantity || 1), 0);
  const wishlistCount = wishlist.length; // Extra helper

  return (
    <CartContext.Provider value={{ 
      cart, 
      orders, 
      wishlist, // Export Wishlist
      addToCart, 
      removeFromCart, 
      updateQuantity, 
      moveToWishlist, 
      removeFromWishlist, // Export Remove Function
      clearCart, 
      cartCount,
      wishlistCount
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within a CartProvider');
  return context;
};