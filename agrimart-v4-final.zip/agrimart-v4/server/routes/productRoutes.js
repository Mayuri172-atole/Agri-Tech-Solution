const express = require('express');
const router = express.Router();
const { 
  getProducts, getProductById, createProduct, 
  updateProduct, approveProduct, deleteProduct 
} = require('../controllers/productController');
const { protect, adminOnly, supplierOnly } = require('../middleware/authMiddleware');

// ✅ FIX: Debug wali console.log line hata di (.red.bold crash kar raha tha)

// Public
router.get('/', getProducts);
router.get('/:id', getProductById);

// Supplier (Farmer or Dealer)
router.post('/', createProduct);

// Admin / Supplier protected routes
router.put('/:id/approve', protect, adminOnly, approveProduct);
router.put('/:id', protect, supplierOnly, updateProduct);
router.delete('/:id', protect, supplierOnly, deleteProduct);

module.exports = router;
